# Skill: Secrets and Credentials

## Purpose
Prevent credentials and secrets from entering frontend source, bundles, logs, or artifacts.

## Never Commit
- API secrets
- Private keys
- Passwords
- Database credentials
- JWT signing secrets
- OAuth client secrets
- Cloud credentials
- Encryption keys
- Production tokens
- Service-account credentials

## Important Rule
Frontend environment variables are not automatically secret. Anything bundled into browser JavaScript can be inspected.

Public configuration is acceptable only when intentionally safe to expose.

## Required Controls
- Use secret scanning in CI.
- Scan Git history when exposure occurs.
- Revoke and rotate exposed production credentials.
- Keep `.env` files containing secrets out of Git.
- Use `.env.example` only with placeholders.

## Review Checklist
- [ ] No hardcoded secrets.
- [ ] No real credentials in examples.
- [ ] Secret scanning passes.
- [ ] Production bundles contain no secrets.
