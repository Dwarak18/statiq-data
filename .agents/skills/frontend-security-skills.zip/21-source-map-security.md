# Skill: Source Map Security

## Purpose
Prevent accidental exposure of source code through production source maps.

## Rules
Before publishing source maps publicly, determine whether they are necessary.

If source maps are needed for error monitoring:
- Upload them privately to the monitoring provider.
- Avoid public exposure unless intentional.
- Ensure source maps contain no secrets.

Remember that source maps can reveal original source structure and code.

## Review Checklist
- [ ] Public source-map exposure is intentional.
- [ ] Secrets are absent.
- [ ] Private maps are access-controlled.
