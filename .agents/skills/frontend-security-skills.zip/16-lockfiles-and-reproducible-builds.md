# Skill: Dependency Lockfiles and Reproducible Builds

## Purpose
Make dependency resolution deterministic and reduce supply-chain surprises.

## Rules
Commit the supported lockfile:
- `package-lock.json`
- `yarn.lock`
- `pnpm-lock.yaml`

CI should use deterministic installation, for example:

```bash
npm ci
```

Avoid uncontrolled dependency resolution during production builds.

## Review Checklist
- [ ] Lockfile is committed.
- [ ] CI uses deterministic installation.
- [ ] Unexpected lockfile changes are reviewed.
