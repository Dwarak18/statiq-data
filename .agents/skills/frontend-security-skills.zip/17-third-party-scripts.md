# Skill: Third-Party Script Security

## Purpose
Control the additional attack surface created by external JavaScript.

## Before Adding a Third-Party Script
Evaluate:
- Business necessity
- Data access
- Execution privileges
- Tracking behavior
- Security history
- Maintenance status
- Safer alternatives

Do not load arbitrary scripts from unknown sources.

## Review Checklist
- [ ] Script source is trusted.
- [ ] Required permissions/data access are understood.
- [ ] Third-party risk is documented.
- [ ] The script is necessary.
