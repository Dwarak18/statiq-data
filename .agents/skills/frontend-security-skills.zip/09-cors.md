# Skill: CORS Security

## Purpose
Prevent overly permissive cross-origin access.

## Rules
CORS is primarily a server-side control. It does not provide authentication or authorization.

Production APIs should use an explicit allowlist of trusted origins.

Avoid unnecessarily permissive configurations such as:

```text
Access-Control-Allow-Origin: *
```

for authenticated applications.

## Review Checklist
- [ ] Trusted origins are explicitly defined.
- [ ] Credentials and origins are configured intentionally.
- [ ] CORS is not being used as an authorization mechanism.
