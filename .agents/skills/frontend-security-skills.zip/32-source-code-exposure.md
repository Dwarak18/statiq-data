# Skill: Frontend Source Exposure

## Purpose
Design under the assumption that browser-delivered code is observable.

Users can inspect:
- JavaScript bundles
- HTML
- CSS
- Network requests
- API endpoints
- Source maps
- Browser storage
- DOM
- WebSocket traffic

Never depend on frontend code being hidden.

## Golden Rule
If a value must remain secret, it does not belong in the frontend.

## Review Checklist
- [ ] No secrets rely on obscurity.
- [ ] Public bundles contain only intentionally public information.
- [ ] Sensitive endpoints enforce server-side controls.
