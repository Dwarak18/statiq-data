# Skill: Security Definition of Done

A security-sensitive frontend feature is complete only when:

- Security requirements have been identified.
- Sensitive data handling has been reviewed.
- Authentication and authorization assumptions are documented.
- Inputs and outputs have been reviewed.
- Dependencies have been checked.
- Secrets have been scanned.
- Security tests have passed.
- Production configuration has been reviewed.
- No known critical security issue remains unresolved.

## Final Principle

The browser is controlled by the user.

The frontend provides a secure user experience, but the backend must enforce security boundaries.

Security must be designed into the system rather than added after implementation.
