# Skill: Frontend Authentication Security

## Purpose
Implement authentication without treating frontend state as a security authority.

## Rules
- Authentication must be enforced by trusted backend infrastructure or an established identity provider.
- Never rely on UI state such as `isAdmin` for authentication.
- Never expose client secrets.
- Use established authentication libraries and protocols.
- Prefer secure server-managed sessions where appropriate.

## Token Handling
Avoid unnecessary storage of sensitive authentication tokens in `localStorage` or `sessionStorage`.

Prefer secure cookies for server-managed sessions with appropriate:
- `Secure`
- `HttpOnly`
- `SameSite`

## Never Log
- Access tokens
- Refresh tokens
- Session cookies
- Authorization headers
- Passwords

## Review Checklist
- [ ] Authentication is independently enforced server-side.
- [ ] Tokens are not logged.
- [ ] Client secrets are absent.
- [ ] Browser token storage has been explicitly reviewed.
