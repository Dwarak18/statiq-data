# Skill: Secure Error Handling

## Purpose
Prevent information leakage through client-facing errors.

## Never Expose
- Stack traces
- Internal file paths
- Database errors
- Secrets
- Internal service names
- Authentication implementation details
- Debug credentials

Prefer generic user-facing messages:

```javascript
throw new Error("Something went wrong. Please try again.");
```

Detailed diagnostics should remain in protected server-side monitoring/logging systems.

## Review Checklist
- [ ] Production errors are generic.
- [ ] Sensitive implementation details are not rendered.
- [ ] Debug output is disabled or controlled in production.
