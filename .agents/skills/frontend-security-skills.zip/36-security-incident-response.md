# Skill: Frontend Security Incident Response

## Purpose
Provide a repeatable response when a frontend security issue is discovered.

## Step 1 — Stop Exposure
Prevent further exposure where possible.

## Step 2 — Identify the Issue
Determine:
- What happened?
- When did it happen?
- Which environments are affected?
- Which users or data may be affected?

## Step 3 — Rotate Credentials
If a credential was exposed:
1. Revoke it.
2. Generate a replacement.
3. Update the affected service.
4. Search Git history and build artifacts.
5. Investigate possible use.

## Step 4 — Preserve Evidence
Do not unnecessarily destroy logs or artifacts needed for investigation.

## Step 5 — Patch
Fix the underlying vulnerability.

## Step 6 — Prevent Recurrence
Identify why the issue entered the codebase and add preventive controls.
