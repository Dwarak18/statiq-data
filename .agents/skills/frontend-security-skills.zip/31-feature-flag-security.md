# Skill: Feature Flag Security

## Purpose
Prevent feature flags from becoming fake authorization controls.

Never rely on:

```javascript
if (featureFlags.canAccessAdmin) {
  // sensitive operation
}
```

Feature flags control application behavior and UX. They do not enforce security.

Security-sensitive capabilities must be authorized server-side.

## Review Checklist
- [ ] Feature flags are not security boundaries.
- [ ] Backend authorization exists for sensitive operations.
