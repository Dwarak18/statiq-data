# Skill: Dependency Security

## Purpose
Reduce supply-chain risk from frontend dependencies.

## Before Adding a Package
- Confirm it is necessary.
- Check maintenance status.
- Review reputation and ownership.
- Check known vulnerabilities.
- Review transitive dependencies.
- Avoid abandoned packages.
- Avoid unnecessary capability-heavy packages.

Run the appropriate package-manager audit, for example:

```bash
npm audit --audit-level=high
```

Critical vulnerabilities must be investigated and remediated before production unless an approved exception exists.

## Review Checklist
- [ ] Dependency purpose is documented.
- [ ] Known vulnerabilities are checked.
- [ ] Lockfile is updated consistently.
- [ ] CI dependency scanning passes.
