# Skill: Frontend Security Testing

## Purpose
Continuously detect frontend vulnerabilities and supply-chain risks.

## Static Analysis
Use appropriate tools such as:
- ESLint security rules
- TypeScript
- Semgrep
- CodeQL

## Dependency Scanning
Use appropriate tools such as:
- npm audit
- Dependabot
- Renovate
- Snyk
- OSV

## Secret Scanning
Use appropriate tools such as:
- Gitleaks
- TruffleHog
- GitHub Secret Scanning

## Dynamic Testing
Where appropriate:
- OWASP ZAP
- Burp Suite
- Browser security testing
- API security testing

## Checklist
- [ ] Static analysis passes.
- [ ] Dependency scan passes.
- [ ] Secret scan passes.
- [ ] Security regression tests pass.
