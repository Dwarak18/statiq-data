# Skill: Input Validation

## Purpose
Prevent malformed or malicious input from reaching sensitive application paths.

## Rules
Frontend validation improves UX but is not a security boundary.

Validate on the backend:
- Type
- Length
- Format
- Allowed values
- Permissions
- Business rules

Frontend checks should provide immediate user feedback but must never replace server-side validation.

## Review Checklist
- [ ] Frontend validation exists where useful.
- [ ] Backend validation independently exists.
- [ ] Security decisions do not depend on disabled controls or client state.
