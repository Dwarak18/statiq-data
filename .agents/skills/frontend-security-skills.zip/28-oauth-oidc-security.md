# Skill: OAuth and OIDC Security

## Purpose
Integrate third-party authentication using established standards.

## Rules
- Use established libraries.
- Use an appropriate authorization code flow for the client type.
- Use PKCE where applicable.
- Validate protocol values according to the identity provider.
- Validate issuer, audience, nonce, state, and tokens as required.
- Never expose client secrets in browser code.

Do not implement authentication protocol validation manually unless there is a compelling, reviewed reason.

## Review Checklist
- [ ] PKCE is used where applicable.
- [ ] State/nonce protections are implemented as required.
- [ ] Client secrets are absent.
- [ ] Tokens are handled securely.
