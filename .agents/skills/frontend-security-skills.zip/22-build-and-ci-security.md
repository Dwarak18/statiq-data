# Skill: Build and CI Security

## Purpose
Prevent insecure code, secrets, and vulnerable dependencies from reaching production.

## Recommended Pipeline

```text
Install
  ↓
Lint
  ↓
Type Check
  ↓
Unit Tests
  ↓
Dependency Audit
  ↓
Secret Scan
  ↓
Security Tests
  ↓
Production Build
  ↓
Artifact Scan
  ↓
Deploy
```

Production builds must not contain:
- Secrets
- Debug credentials
- Test accounts
- Private keys
- Development-only debug code
- Unnecessary internal configuration

## Review Checklist
- [ ] CI performs security checks.
- [ ] Secrets are scanned.
- [ ] Dependencies are audited.
- [ ] Build artifacts are scanned.
