# Skill: Frontend File Upload Security

## Purpose
Reduce risks associated with user-uploaded files.

## Rules
The frontend should validate for usability, but backend validation remains the security boundary.

Validate or constrain:
- File size
- Expected file types
- Number of files
- Upload destination/workflow

Do not trust file extensions or `file.type` as sufficient security validation.

Avoid rendering uploaded content as executable content.

## Review Checklist
- [ ] File size limits exist.
- [ ] Expected types are constrained.
- [ ] Backend independently validates uploads.
- [ ] Uploaded content cannot execute unexpectedly.
