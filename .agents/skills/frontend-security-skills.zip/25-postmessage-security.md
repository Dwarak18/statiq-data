# Skill: postMessage Security

## Purpose
Prevent cross-origin message abuse.

When using `window.postMessage()`, validate:
- `event.origin`
- `event.source`
- Message structure
- Message type
- Allowed actions

Never blindly execute received message data.

Bad:

```javascript
window.addEventListener("message", (event) => {
  execute(event.data);
});
```

## Review Checklist
- [ ] Allowed origins are explicit.
- [ ] Message schema is validated.
- [ ] Received data cannot become executable code.
