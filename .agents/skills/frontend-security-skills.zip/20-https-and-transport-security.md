# Skill: HTTPS and Transport Security

## Purpose
Protect application traffic from interception and downgrade attacks.

## Rules
- Production must use HTTPS.
- Sensitive information must never be sent over plain HTTP.
- Eliminate mixed content.
- Use HSTS where appropriate.
- Use `wss://` for production WebSockets.

Avoid loading HTTP resources from an HTTPS application.

## Review Checklist
- [ ] All production endpoints use HTTPS.
- [ ] No mixed content remains.
- [ ] HSTS is configured where appropriate.
