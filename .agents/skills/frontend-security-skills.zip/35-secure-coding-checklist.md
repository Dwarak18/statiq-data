# Skill: Secure Coding Checklist

Use this checklist before merging frontend code.

- [ ] No hardcoded secrets.
- [ ] No passwords or tokens in logs.
- [ ] No unsafe HTML injection.
- [ ] No unnecessary `eval()`.
- [ ] No unsafe dynamic JavaScript execution.
- [ ] User-controlled URLs are validated.
- [ ] External input is treated as untrusted.
- [ ] Backend authorization is not replaced by frontend checks.
- [ ] Sensitive data is not unnecessarily stored in browser storage.
- [ ] Authentication tokens are handled securely.
- [ ] Dependencies have been reviewed.
- [ ] No known critical dependency vulnerabilities remain unresolved.
- [ ] No accidental `.env` or credential files are committed.
- [ ] Production build contains no secrets.
- [ ] Debug logging has been reviewed.
- [ ] Third-party scripts have been reviewed.
- [ ] Security-sensitive changes have been reviewed.
- [ ] Tests pass.
- [ ] Linting passes.
- [ ] Type checking passes.
- [ ] Secret scanning passes.
- [ ] Dependency scanning passes.
