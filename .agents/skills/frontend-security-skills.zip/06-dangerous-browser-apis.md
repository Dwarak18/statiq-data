# Skill: Dangerous Browser APIs

## Purpose
Identify and safely review browser APIs that can create code execution or injection risks.

## High-Risk APIs
Review carefully:
- `innerHTML`
- `outerHTML`
- `insertAdjacentHTML()`
- `document.write()`
- `eval()`
- `new Function()`
- String-based `setTimeout()`
- String-based `setInterval()`

Never execute user-controlled strings as JavaScript.

## Required Review
If a dangerous API is unavoidable, document:
1. Why it is necessary.
2. What data reaches it.
3. How that data is validated or sanitized.
4. Why safer alternatives are unsuitable.

## Review Checklist
- [ ] No unnecessary dynamic code execution.
- [ ] Dangerous API usage is reviewed.
- [ ] Input reaching the API is controlled and sanitized.
