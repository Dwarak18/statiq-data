# Skill: Sensitive Data Handling

## Purpose
Minimize exposure of sensitive user and application data.

## Avoid Unnecessary Browser Storage
Do not unnecessarily store:
- Passwords
- Authentication tokens
- Payment information
- Government identifiers
- Private documents
- Recovery codes
- Security answers

## Do Not Expose Sensitive Data Through
- URLs
- Query strings
- DOM attributes
- HTML comments
- JavaScript bundles
- Client logs
- Analytics
- User-facing errors

Keep sensitive data in memory for the shortest practical period.

## Review Checklist
- [ ] Data collection is minimized.
- [ ] Browser persistence is justified.
- [ ] Sensitive values are excluded from URLs and logs.
