# Skill: OWASP Security Alignment

## Purpose
Keep frontend security practices aligned with recognized application-security guidance.

Review applicable guidance from:
- OWASP Top 10
- OWASP ASVS
- OWASP Cheat Sheet Series
- OWASP Web Security Testing Guide

Use current versions of these resources rather than relying on outdated checklists.

## Review Checklist
- [ ] Security standards are periodically reviewed.
- [ ] Applicable OWASP controls are mapped to the application.
- [ ] Major security changes are documented.
