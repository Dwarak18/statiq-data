# Skill: Git and Repository Security

## Purpose
Prevent secrets and sensitive artifacts from entering version control.

Do not commit:
- `.env`
- `.env.local`
- `.env.production`
- `*.pem`
- `*.key`
- `credentials.json`
- `service-account.json`
- Private certificates

Example `.gitignore`:

```gitignore
.env
.env.*
!.env.example

*.pem
*.key

credentials.json
service-account.json
```

If a secret was committed, remove it from exposure and rotate it. Removing it from the latest commit alone is insufficient if it exists in Git history.

## Review Checklist
- [ ] Secret files are ignored.
- [ ] Secret scanning passes.
- [ ] Exposed credentials are rotated.
