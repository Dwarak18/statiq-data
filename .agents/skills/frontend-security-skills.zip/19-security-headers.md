# Skill: Security Headers

## Purpose
Apply browser security headers that reduce common attack classes.

Where appropriate, use:
- `Content-Security-Policy`
- `Strict-Transport-Security`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy`
- `Permissions-Policy`

For clickjacking protection, prefer CSP `frame-ancestors` with an appropriate policy.

## Review Checklist
- [ ] Production headers are configured.
- [ ] HSTS is appropriate for the deployment.
- [ ] Referrer behavior is intentional.
- [ ] Framing policy is intentional.
