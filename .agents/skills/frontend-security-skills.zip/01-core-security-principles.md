# Skill: Core Frontend Security Principles

## Purpose
Apply baseline security principles to every frontend change.

## Rules
- Never trust client-side input.
- Never store secrets in frontend code.
- Never treat frontend validation as a security boundary.
- Treat API responses and external content as untrusted.
- Minimize sensitive data in the browser.
- Use HTTPS everywhere.
- Keep dependencies updated and audited.
- Prefer established browser/framework security mechanisms.
- Fail securely.
- Do not expose unnecessary internal implementation details.

## Review Checklist
- [ ] Inputs are treated as untrusted.
- [ ] No secrets are shipped to the browser.
- [ ] Security boundaries remain server-side.
- [ ] Sensitive data exposure is minimized.
- [ ] Secure defaults are used.
