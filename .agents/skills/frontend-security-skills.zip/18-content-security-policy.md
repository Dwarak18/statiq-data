# Skill: Content Security Policy

## Purpose
Use CSP to reduce the impact of XSS and unauthorized script execution.

A starting policy may look like:

```text
Content-Security-Policy:
  default-src 'self';
  script-src 'self';
  style-src 'self';
  img-src 'self' data: https:;
  connect-src 'self' https://api.example.com;
  object-src 'none';
  base-uri 'self';
  frame-ancestors 'none';
```

Customize the policy for actual application requirements.

Avoid `unsafe-inline` and `unsafe-eval` unless explicitly required and security-reviewed.

## Review Checklist
- [ ] CSP exists in production where appropriate.
- [ ] Sources are narrowly scoped.
- [ ] Unsafe directives are avoided.
- [ ] CSP changes receive security review.
