# Skill: CSRF Protection

## Purpose
Protect cookie-authenticated applications from cross-site request forgery.

## Rules
Applications using cookie-based authentication must implement appropriate CSRF defenses.

Possible controls:
- `SameSite` cookies
- CSRF tokens
- Origin validation
- Referer validation where appropriate
- Backend request validation

Do not assume the frontend framework automatically solves CSRF.

## Review Checklist
- [ ] Cookie-authenticated state-changing requests have CSRF protection.
- [ ] Backend validates security tokens where required.
- [ ] Cross-origin request assumptions are documented.
