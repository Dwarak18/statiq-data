# Skill: Cryptography Security

## Purpose
Prevent insecure custom cryptographic implementations.

## Rules
Never invent custom encryption or hashing algorithms.

Use established, reviewed primitives and libraries.

Avoid:

```javascript
function myOwnEncryption(data) {
  // custom cryptography
}
```

Use browser cryptographic APIs or trusted libraries where appropriate.

Passwords must not be hashed in frontend JavaScript as a replacement for proper server-side password handling.

## Review Checklist
- [ ] No custom cryptographic algorithm.
- [ ] Established primitives are used.
- [ ] Key material is handled securely.
- [ ] Password handling remains server-side.
