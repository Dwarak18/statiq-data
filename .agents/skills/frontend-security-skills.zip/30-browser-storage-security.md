# Skill: Browser Storage Security

## Purpose
Prevent sensitive information from being unnecessarily persisted in the browser.

Before storing data in:
- `localStorage`
- `sessionStorage`
- IndexedDB
- Cookies

ask:
1. Is the data sensitive?
2. Does it need persistence?
3. Can it remain in memory?
4. Can JavaScript access it?
5. What is the impact of XSS?

Minimize stored data and retention.

## Review Checklist
- [ ] Storage is necessary.
- [ ] Sensitive data is minimized.
- [ ] Cookie attributes are appropriate.
- [ ] XSS impact has been considered.
