# Skill: Frontend Authorization

## Purpose
Prevent frontend UI logic from being mistaken for real authorization.

## Rules
Frontend checks may control UX but MUST NOT enforce security-sensitive access.

Bad pattern:

```javascript
if (user.role === "admin") {
  showDeleteButton();
}
```

The backend must independently enforce:
- Roles
- Permissions
- Resource ownership
- Tenant boundaries
- Sensitive operations

## Security Boundary

User -> Authentication -> Authorization -> Resource Access

## Review Checklist
- [ ] Backend authorization exists.
- [ ] Hidden buttons are not treated as protection.
- [ ] API endpoints enforce permissions.
- [ ] Resource ownership is verified server-side.
