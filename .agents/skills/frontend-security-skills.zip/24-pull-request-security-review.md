# Skill: Pull Request Security Review

## Purpose
Make security review a standard part of frontend code review.

## Review Security-Sensitive Changes
- Authentication
- Authorization
- Token handling
- API clients
- URL handling
- HTML rendering
- Third-party integrations
- Dependencies
- Browser storage
- Security headers
- CSP
- Build configuration
- Environment variables

## Search For
```text
innerHTML
dangerouslySetInnerHTML
eval
localStorage
sessionStorage
document.cookie
postMessage
window.location
iframe
WebSocket
fetch
XMLHttpRequest
```

These APIs are not automatically vulnerable, but they deserve deliberate review.

## Checklist
- [ ] Security implications are understood.
- [ ] New dependencies are reviewed.
- [ ] Sensitive data flows are understood.
- [ ] Security tests pass.
