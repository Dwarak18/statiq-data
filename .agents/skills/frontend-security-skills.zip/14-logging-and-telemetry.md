# Skill: Secure Logging and Telemetry

## Purpose
Prevent sensitive information from entering logs, analytics, or error-reporting systems.

## Never Log
- Passwords
- Access tokens
- Refresh tokens
- Authorization headers
- Session cookies
- Private keys
- Payment information
- Sensitive personal data
- Security answers

Review analytics and telemetry payloads for accidental leakage.

## Review Checklist
- [ ] Authentication credentials are never logged.
- [ ] Sensitive request/response bodies are excluded.
- [ ] Production debugging is controlled.
- [ ] Error monitoring is configured to redact sensitive fields.
