# Skill: URL and Redirect Security

## Purpose
Prevent malicious URL handling, open redirects, and dangerous protocol execution.

## Rules
Never blindly trust URLs from users or external systems.

Pay particular attention to:
- `javascript:`
- `data:`
- `vbscript:`

Avoid:

```javascript
window.location.href = userProvidedUrl;
```

unless the destination is strictly validated.

Prefer trusted application routes and explicit allowlists.

## Redirects
Validate redirect destinations to prevent open redirects such as:

```text
/login?redirect=https://attacker.example
```

## Review Checklist
- [ ] User-controlled URLs are validated.
- [ ] Dangerous schemes are rejected.
- [ ] Redirect destinations are allowlisted where appropriate.
