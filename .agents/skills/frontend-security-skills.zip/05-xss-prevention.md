# Skill: XSS Prevention

## Purpose
Prevent reflected, stored, and DOM-based cross-site scripting.

## Rules
Treat all external data as untrusted:
- User input
- URL parameters
- Query strings
- API responses
- CMS content
- Third-party content
- Browser storage
- `postMessage` data

Prefer framework/browser escaping.

Avoid raw HTML injection such as:

```javascript
element.innerHTML = userInput;
```

Prefer:

```javascript
element.textContent = userInput;
```

Framework APIs that intentionally bypass escaping require security review and appropriate sanitization.

## Review Checklist
- [ ] User-controlled content is escaped.
- [ ] Raw HTML rendering has a documented reason.
- [ ] Sanitization is performed where required.
- [ ] No untrusted content reaches executable contexts.
