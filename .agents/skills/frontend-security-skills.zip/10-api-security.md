# Skill: Frontend API Security

## Purpose
Ensure browser API clients communicate safely with backend services.

## Requirements
- Use HTTPS.
- Handle non-2xx responses safely.
- Validate expected response structures.
- Do not log sensitive payloads.
- Do not expose internal errors to users.
- Send only necessary data.
- Use appropriate timeouts and cancellation.
- Handle malformed or unexpected responses safely.

Example:

```javascript
const response = await fetch("/api/profile");

if (!response.ok) {
  throw new Error("Request failed");
}

const data = await response.json();
```

## Security Boundary
The backend must independently validate every request and enforce authorization.
