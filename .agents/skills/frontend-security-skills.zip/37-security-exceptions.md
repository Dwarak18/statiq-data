# Skill: Security Exceptions

## Purpose
Document and control deviations from security requirements.

Every exception should record:

```text
Requirement:
Reason:
Risk:
Affected components:
Mitigation:
Owner:
Approval:
Expiration/review date:
```

Security exceptions must have an owner and review date.

Avoid permanent undocumented workarounds.

## Review Checklist
- [ ] Exception is documented.
- [ ] Risk is understood.
- [ ] Mitigation exists.
- [ ] Owner is assigned.
- [ ] Expiration/review date exists.
