# Skill: WebSocket Security

## Purpose
Secure real-time browser connections.

## Rules
Use:

```text
wss://
```

in production.

Authentication and authorization must still be enforced server-side.

Do not assume that an established WebSocket connection grants permission to perform every action.

## Review Checklist
- [ ] Production uses secure WebSockets.
- [ ] Authentication is enforced.
- [ ] Authorization is enforced for individual operations.
- [ ] Sensitive messages are not logged.
